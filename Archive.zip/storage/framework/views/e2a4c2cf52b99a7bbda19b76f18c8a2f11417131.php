<?php $__env->startSection('content'); ?>

<ul class="errors">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<section class="content"> 
    <div class="white">
        <ul class="nav-menu"> 
            <li><a href="/item">Home</a></li>
            <li><a href="/guardarropa">Guardarropa</a></li>
            <li><a href="/outfit">Looks</a></li>
            <li><a href="/guardarropa">Assistant</a></li>
            <li><a href="/producto/shop">Shop</a></li>
        </ul>
    </div>

    <div class="BannerWardrobe">
        <p>Completá el look que más te guste</p>
    </div>
</section>

<section class="principal">
<?php if($find !== 0): ?>
    <?php $__currentLoopData = $qtotal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
            <?php if($q !== 0): ?>
                <?php for($i=0 ; $i<$q ; $i++ ): ?>
                <form method= "POST" id="outfit" action="" name="outfit" style="text-align:center;margin-bottom:50px;" enctype="multipart/form-data">
                <?php echo csrf_field(); ?> 
                 
                <?php if(isset($mensaje)): ?>
                     <p> <?php echo e($mensaje); ?> </p>
                <?php endif; ?>
            
                <div class="index margin10">         
                <ul class="cajaOutfit2">               
                    <li class="column3">                                
                        <div class="boxtop">
                            <?php $__currentLoopData = $qb[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qBot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $qo[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qOut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                            <?php $__currentLoopData = $qt[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qTop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                    
                                <?php if(($qTop !== $qBot && $qTop !== $qOut && $qBot !== $qOut ) || $qTop === 1): ?>                             
                                    <?php if($i<$qTop): ?>
                                        <img class="topFor" name="top" id="<?php echo e($conjunto[$key][0][$i][1]); ?>" src="<?php echo e(asset($conjunto[$key][0][$i][0])); ?>" alt="TOP">
                                        <input type="hidden" name="top" value="<?php echo e($conjunto[$key][0][$i][1]); ?>">
                                    <?php else: ?>
                                        <img class="topFor" name="top" id="<?php echo e($conjunto[$key][0][$i-floor($i/$qTop) * $qTop][1]); ?>" src="<?php echo e(asset($conjunto[$key][0][$i-floor($i/$qTop) * $qTop][0])); ?>" alt="TOP">
                                        <input type="hidden" name="top" value="<?php echo e($conjunto[$key][0][$i-floor($i/$qTop) * $qTop][1]); ?>">
                                    <?php endif; ?>
                                <?php elseif($qBot === 1 && $qOut === 1): ?>
                                    <?php if($i<$qTop): ?>                                   
                                        <img class="topFor" name="top" id="<?php echo e($conjunto[$key][0][$i][1]); ?>" src="<?php echo e(asset($conjunto[$key][0][$i][0])); ?>" alt="TOP">
                                        <input type="hidden" name="top" value="<?php echo e($conjunto[$key][0][$i][1]); ?>">
                                    <?php else: ?>                                   
                                        <img class="topFor" name="top" id="<?php echo e($conjunto[$key][0][$i-floor($i/$qTop)*$qTop][1]); ?>" src="<?php echo e(asset($conjunto[$key][0][$i-floor($i/$qTop)*$qTop][0])); ?>" alt="TOP">
                                        <input type="hidden" name="top" value="<?php echo e($conjunto[$key][0][$i-floor($i/$qTop)*$qTop][1]); ?>">
                                    <?php endif; ?> 
                                <?php else: ?>
                                        <img class="topFor" name="top" id="<?php echo e($conjunto[$key][0][floor($i/$qTop)][1]); ?>" src="<?php echo e(asset($conjunto[$key][0][floor($i/$qTop)][0])); ?>" alt="TOP">                              
                                        <input type="hidden" name="top" value="<?php echo e($conjunto[$key][0][floor($i/$qTop)][1]); ?>">
                                <?php endif; ?>                                                                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="boxacc">
                            <img class="bag" id="" alt="Click to Choose BAG">
                            <input type="hidden" class="subirBag">
                        </div>
                    </li>
                    <li class="column4">    
                        <div class="boxbottom">
                            <?php $__currentLoopData = $qb[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qBot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                    
                                <?php if(($qTop !== $qBot && $qTop !== $qOut && $qBot !== $qOut ) || ($qBot === 1)): ?>                      
                                    <?php if($i<$qBot): ?>      
                                        <img class="bottomFor" name="bottom" id="<?php echo e($conjunto[$key][1][$i][1]); ?>" value="<?php echo e($conjunto[$key][1][$i][1]); ?>" src="<?php echo e(asset($conjunto[$key][1][$i][0])); ?>" alt="BOTTOM">
                                        <input type="hidden" name="bottom" value="<?php echo e($conjunto[$key][1][$i][1]); ?>">
                                    <?php else: ?>
                                        <img class="bottomFor" name="bottom" id="<?php echo e($conjunto[$key][1][$i-floor($i/$qBot) * $qBot][1]); ?>" value="<?php echo e($conjunto[$key][1][$i-floor($i/$qBot) * $qBot][1]); ?>" src="<?php echo e(asset($conjunto[$key][1][$i-floor($i/$qBot) * $qBot][0])); ?>" alt="BOTTOM">
                                        <input type="hidden" name="bottom" value="<?php echo e($conjunto[$key][1][$i-floor($i/$qBot) * $qBot][1]); ?>">
                                    <?php endif; ?>
                                <?php elseif(($qTop === 1 && $qOut === 1) || ($qBot === 1 && $qOut === 1) || ($qBot === $qTop) ): ?>                                                    
                                    <?php if($i<$qBot): ?>      
                                        <img class="bottomFor" name="bottom" id="<?php echo e($conjunto[$key][1][$i][1]); ?>" value="<?php echo e($conjunto[$key][1][$i][1]); ?>" src="<?php echo e(asset($conjunto[$key][1][$i][0])); ?>" alt="BOTTOM">
                                        <input type="hidden" name="bottom" value="<?php echo e($conjunto[$key][1][$i][1]); ?>">
                                    <?php else: ?>
                                        <img class="bottomFor" name="bottom" id="<?php echo e($conjunto[$key][1][$i-floor($i/$qBot) * $qBot][1]); ?>" value="<?php echo e($conjunto[$key][1][$i-floor($i/$qBot) * $qBot][1]); ?>" src="<?php echo e(asset($conjunto[$key][1][$i-floor($i/$qBot) * $qBot ][0])); ?>" alt="BOTTOM">
                                        <input type="hidden" name="bottom" value="<?php echo e($conjunto[$key][1][$i-floor($i/$qBot) * $qBot][1]); ?>">
                                    <?php endif; ?>
                                <?php else: ?>
                                    <img class="bottomFor" name="botton" id="<?php echo e($conjunto[$key][1][floor($i/$qBot)][1]); ?>" value="<?php echo e($conjunto[$key][1][floor($i/$qBot)][1]); ?>" src="<?php echo e(asset($conjunto[$key][1][floor($i/$qBot)][0])); ?>" alt="BOTTOM"> 
                                    <input type="hidden" name="bottom" value="<?php echo e($conjunto[$key][1][floor($i/$qBot)][1]); ?>">
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </li>
                    <li class="column5">
                        <div class="boxoutwear">                 
                            <?php $__currentLoopData = $qo[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qOut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <?php if($i<$qOut): ?>                    
                                    <img class="outFor" name="outwear" id="<?php echo e($conjunto[$key][2][$i][1]); ?>" src="<?php echo e(asset($conjunto[$key][2][$i][0])); ?>" alt="OUTWEAR">
                                    <input type="hidden" name="outwear" value="<?php echo e($conjunto[$key][2][$i][1]); ?>">
                                <?php else: ?>                            
                                    <img class="outFor" name="outwear" id="<?php echo e($conjunto[$key][2][$i-floor($i/$qOut) * $qOut][1]); ?>" src="<?php echo e(asset($conjunto[$key][2][$i-floor($i/$qOut) * $qOut][0])); ?>" alt="OUTWEAR">                           
                                    <input type="hidden" name="outwear" value="<?php echo e($conjunto[$key][2][$i-floor($i/$qOut) * $qOut][1]); ?>">
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>                                                                                                                               
                        <div class="boxshoes">
                            <img class="shoes" id="" alt="Click to Choose SHOES">
                            <input type="hidden" class="subirShoes">
                        </div>                                           
        <!-- <img class="other" src="" alt="Choose OTHER">  -->
                    </li>                      
                </ul> 
            </div>   
            <article class="index">
                <div class="navUso">
                    <div class="cajaUso">                       
                        <label for=""></label>
                        <input type="checkbox" name="work" value="1" class="work" selected>Work
                        <input type="checkbox" name="day" value="1" class="day" selected>Day
                        <input type="checkbox" name="night" value="1" class="night" selected>Night                       
                    </div>    
                    <button class="myPreferido botonGuardarOut">Guardar</button>        
                </div>
            </article>
            </form>

                <?php endfor; ?>
            <?php endif; ?>          
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <ul class="container">
        <p>No se han encontrado conjuntos completos para esta prenda</p>
    </ul>    
<?php endif; ?>
    <script src="../js/wglam.js"></script>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>