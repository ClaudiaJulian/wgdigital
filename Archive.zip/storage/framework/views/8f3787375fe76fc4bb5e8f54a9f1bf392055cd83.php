<?php $__env->startSection('content'); ?>


<section class="content">
    
    <div class="white">
        <ul class="nav-menu">                                   
            <li><a href="/item">Home</a></li>         
            <li><a href="/guardarropa">Mi Guardarropa</a></li>                
            <li><a href="/outfit">Mis Looks</a></li>            
            <li><a href="/producto/shop">Shop</a></li>
            <li><a href="/guardarropa">Ayuda</a></li>                    
        </ul>  
    </div>
    <div class="BannerWardrobe">
        <p>Con un click armá tu outfit preferido</p>
    </div>

</section>
<section class="principal">    

    <form method= "POST" id="masteroutfit" action="" name="masteroutfit" style="text-align: center;" enctype="multipart/form-data">
       <div class="index margin10"> 
        <ul class="cajaOutfit2">
            <li class="column3"> 
                <div class="boxtop">                               
                    <img class="masterTop topFor" id="" alt="Click to Choose TOP">
                    <input type="hidden" class="subirTop" >
                </div>
                <div class="boxacc">
                    <img class="masterBag" id="" alt="Click to Choose BAG">
                </div>
            </li>
            <li class="column4">     
                <div class="boxbottom">
                    <img class="masterBottom bottomFor" id="" alt="Click to Choose BOTTOM">
                </div>                 
            </li>
            <li class="column5">
                <div class="boxoutwear">
                    <img class="masterOutwear outFor" id="" alt="Click to Choose OUTWEAR">
                </div>
                <div class="boxshoes">
                    <img class="masterShoes" id="" alt="Click to Choose SHOES">
                </div>                   
        <!-- <img class="other" src="" alt="Choose OTHER">  -->
            </li>               
        </ul>
        </div>
        
    </form>
    <div class="index">                        
        <button class="botonGral"><a href="/item">Compartir</a></button> 
    </div>

    <script src="../js/wglam.js"></script>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>