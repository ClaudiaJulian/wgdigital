<?php $__env->startSection('content'); ?>


<section class="content">
    <article> 
        <h2 class="titulo">><?php echo e($categoria->name); ?></h2>
    </article> 
    
    <div class="index">
        <p><a class="links" href="/item">Items</a></p>
        <p><a class="links" href="/categoria">Categorias</a></p>
    </div>

    <div class="index">
        <?php $__currentLoopData = $categoria->item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="">
            <a class="links" href="../item/<?php echo e($item->id); ?>">
                <ul>
                <img src="<?php echo e(asset($item->photo)); ?>" alt="Icono de <?php echo e($item->name); ?>">
                <h3><?php echo e($item->name); ?></h3>
                </ul>
            </a>         
        </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>   
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>