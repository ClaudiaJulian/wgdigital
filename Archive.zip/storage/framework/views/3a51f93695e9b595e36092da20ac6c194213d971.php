<?php $__env->startSection('content'); ?>

<ul class="errors">
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<section class="white">
        <ul class="nav-menu">          
            <li><a href="/item/create"> Item </a></li>    
            <li><a href="/categoria">Categorías</a></li>
            <li><a href="/formula">Formulas</a></li>
            <li><a href="/categoria">Suscripciones</a></li>
            <li><a href="/adm/user">Roles</a></li>
            <li><a href="/categoria">Mensajes</a></li>
            <li><a href="/categoria">Gestion</a></li>      
        </ul>
</section>

<section class="principal">
<form method="POST" id="nuevo" action="" name="nuevo" style="text-align: center;" enctype="multipart/form-data"> 
    <?php echo csrf_field(); ?>  
    <ul>      
    <label for="cuerpo"></label>
        <select name="cuerpo" type="number">
            <option>cuerpo</option>
            <?php $__currentLoopData = $cuerpo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
            <option value=<?php echo e($c['nombre']); ?>><?php echo e($c['nombre']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </ul>

    <ul>    
    <label for="categoria_1"></label>
        <select name="categoria_1" type="number">
            <option >categoria_1</option>
            <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
            <option value=<?php echo e($cat['name']); ?>><?php echo e($cat['name']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

    <label for="form_1"></label>
        <select name="form_1" type="number">
            <option value>form_1</option>
            <?php $__currentLoopData = $forma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
            <option value=<?php echo e($f['id']); ?>><?php echo e($f['nombre']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

    <label for="printed_1"></label>
        <select name="printed_1" type="number">
            <option >printed_1</option>
            <?php $__currentLoopData = $estampado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
            <option value=<?php echo e($e['id']); ?>><?php echo e($e['nombre']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

    <label for="colored_1"></label>
        <select name="colored_1" type="number">
            <option >colored_1</option>
            <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
            <option value=<?php echo e($col['id']); ?>><?php echo e($col['nombre']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>     
    
    <label for="length_1"></label>
        <select name="length_1" type="number">
            <option >length_1</option>
            <?php $__currentLoopData = $largo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
            <option value=<?php echo e($l['id']); ?>><?php echo e($l['nombre']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select> 

    </ul>

    <ul>    
    <label for="categoria_2"></label>
        <select name="categoria_2" type="number">
            <option >categoria_2</option>
            <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
            <option value=<?php echo e($cat['name']); ?>><?php echo e($cat['name']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        
    <label for="form_2"></label>
        <select name="form_2" type="number">
            <option value>form_2</option>
            <?php $__currentLoopData = $forma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
            <option value=<?php echo e($f['id']); ?>><?php echo e($f['nombre']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        
    <label for="printed_2"></label>
        <select name="printed_2" type="number">
            <option >printed_2</option>
            <?php $__currentLoopData = $estampado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
            <option value=<?php echo e($e['id']); ?>><?php echo e($e['nombre']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        
    <label for="colored_2"></label>
        <select name="colored_2" type="number">
            <option >colored_2</option>
            <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
            <option value=<?php echo e($col['id']); ?>><?php echo e($col['nombre']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>     
            
    <label for="length_2"></label>
        <select name="length_2" type="number">
            <option >length_2</option>
            <?php $__currentLoopData = $largo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
            <option value=<?php echo e($l['id']); ?>><?php echo e($l['nombre']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select> 
        
    </ul>

    <ul>
    <label for="categoria_3"></label>
        <select name="categoria_3" type="number">
            <option >categoria_3</option>
            <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
            <option value=<?php echo e($cat['name']); ?>><?php echo e($cat['name']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
                
    <label for="form_3"></label>
        <select name="form_3" type="number">
            <option value>form_3</option>
            <?php $__currentLoopData = $forma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
            <option value=<?php echo e($f['id']); ?>><?php echo e($f['nombre']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
                
    <label for="printed_3"></label>
        <select name="printed_3" type="number">
            <option >printed_3</option>
            <?php $__currentLoopData = $estampado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
            <option value=<?php echo e($e['id']); ?>><?php echo e($e['nombre']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
                
    <label for="colored_3"></label>
        <select name="colored_3" type="number">
            <option >colored_3</option>
            <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
            <option value=<?php echo e($col['id']); ?>><?php echo e($col['nombre']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>     
                    
    <label for="length_3"></label>
        <select name="length_3" type="number">
            <option >length_3</option>
            <?php $__currentLoopData = $largo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
            <option value=<?php echo e($l['id']); ?>><?php echo e($l['nombre']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select> 
                
    </ul>
        
    <button type="submit" name="button">Guardar</button>
   
</form>


</section>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>