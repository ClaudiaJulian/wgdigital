<?php $__env->startSection('content'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<section class="content">
    
    <div class="white">
        <ul class="nav-menu">                                   
            <li><a href="/item">Home</a></li>         
            <li><a href="/guardarropa">Mi Guardarropa</a></li>                
            <li><a href="/outfit">Mis Looks</a></li>            
            <li><a href="/producto/shop">Shop</a></li>
            <li><a href="/guardarropa">Ayuda</a></li>                    
        </ul>  
    </div>
    
    <div class="BannerWardrobe">
        <?php if(isset($seller)): ?> <p style="background-color:red;"> <?php echo e($seller); ?> </p> <?php else: ?>
        <p>Clickeá y grabá el conjunto que más te guste</p>
        <?php endif; ?>
    </div>
  
</section>

<section class="principal">
    <ul class="errors">
        <?php if($errors->all()): ?><li> Faltan completar datos.</li> <?php endif; ?>        
        
    </ul>

    <?php if(isset($seller)): ?> <p><?php echo e('Conectate con wGlam'); ?></p> <?php else: ?> 
    <form method= "POST" id="outfit" action="" name="outfit" style="text-align: center;" enctype="multipart/form-data">
        <?php echo csrf_field(); ?> 
        <?php if(isset($mensaje)): ?>             
            <p> <?php echo e($mensaje); ?> </p>
        <?php endif; ?>
     <div class="index margin10">    
         <ul class="cajaOutfit2">
             <li class="column3"> 
                 <div class="boxtop">                              
                     <img class="on top" alt="Click to Choose TOP">
                     <input type="hidden" class="subirTop" >
                 </div>

                 <div class="boxacc">
                    <img class="bag"  alt="Click to Choose BAG">
                    <input type="hidden" class="subirBag">
                </div>  
            </li>
            <li class="column4">  
                 <div class="boxbottom">
                     <img class="bottom" alt="Click to Choose BOTTOM">
                     <input type="hidden" class="subirBottom">
                 </div>                 
             </li>

             <li class="column5">
                 <div class="boxoutwear">
                     <img class="outwear" alt="Click to Choose OUTWEAR">
                     <input type="hidden" class="subirOutwear">
                 </div>
               
                 <div class="boxshoes">
                      <img class="shoes" alt="Click to Choose SHOES"> 
                      <input type="hidden" class="subirShoes">
                 </div>                   
         <!-- <img class="other" src="" alt="Choose OTHER">  -->
             </li>               
         </ul>
     </div>    
     <article class="index">    
        <div class="navUso">
            <div class="cajaUso">                                        
                <label for=""></label>
                 <input type="checkbox" name="work" value="1" selected>Work
                 <input type="checkbox" name="day" value="1" selected>Day
                 <input type="checkbox" name="night" value="1" selected>Night 
            </div>                   
            <button class="myCreate botonGuardarOut">Guardar</button>        
        </div>
    <article>    
    </form> 
    
     <script rel="javascript" type="text/javascript" src="../js/wglam.js"></script> 
    <?php endif; ?>       
 </section>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>