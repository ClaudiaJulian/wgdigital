<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>" prefix="og:http://ogp.me/ns#">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    <title>wGlam</title>
    <meta property="og:title" content="myOutfit" />
    <meta property="og:type" content="image/jpeg" />
    <meta property="og:url" content="http://127.0.0.1:8000/item/55" />
    <meta property="og:image" content="<?php echo e(asset('/flequillo.jpg')); ?>" />

    <!-- Fonts -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=M+PLUS+Rounded+1c:300,400,500,700" rel="stylesheet"> 
    

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>

<body>
  <div class="container">
      <header class="main-header">
          <nav class="nav-logo-icon">
            <div class="cajalogo"> 
                <img src="<?php echo e(asset('/wGlam.png')); ?>" alt="wGlam"  class="logo">              
            </div>

            <div class="nav-iconos">
              <?php if(Auth::check()): ?>
                <?php if(Auth::user()->role === "adm"): ?> <a href="/adm/user">Adm</a> <?php endif; ?>
                <a href="/perfil/<?php echo e(Auth::user()->id); ?>/edit" style="margin:10px;"><?php echo e(Auth::user()->name); ?></a>
                
                
                <a style="margin:5px 10px 5px 10px;">Plan<?php echo e(Auth::user()->abono); ?></a>
                
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                  onclick="event.preventDefault();
                  document.getElementById('logout-form').submit();" style="margin:10px;">
                  <?php echo e(__('Logout')); ?>

                </a>
            
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                  <?php echo csrf_field(); ?>
                </form>
                
              <?php else: ?>   
                <a href="<?php echo e(route('login')); ?>" style="margin:10px;">Login</a>
                <a href="<?php echo e(route('register')); ?>" style="margin:10px;">Register</a>    
              <?php endif; ?>
                
            </div>
          </nav>
    </header>
  </div>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="indColumn">
      
      <div class="index" style="padding:10px;font-size:0.8em;">
        <!-- Sitio -->  
        <ul style="width:30vw; color:grey;border-right:solid lightgrey 1px;">
              <li ><a style="color:grey" href="/item">Home</a></li>                    
              <li ><a style="color:grey" href="/producto/shop">Shop</a></li>
              <li ><a style="color:grey" href="/guardarropa">FAQ</a></li> 
          </ul>
         <!-- Sitio -->  
         <ul style="width:30vw; color:grey;border-right:solid lightgrey 1px;">
            <li>Contacto Comercial</li>
            <li>Términos y Condiciones</li>   
        </ul> 
        <!-- Redes -->  
        <ul style="width:30vw; color:grey;">
            <li>Facebook</li>
            <li>Instagram</li>
            
        </ul>   
      </div> 
      <div style="padding:30px;color:grey;font-size:0.8em;">
        <span >wGlam</span>
        <span>copyright | Todos los derechos reservados.</span>
      </div> 
    </footer>
    
    
  
</body>
</html>
  