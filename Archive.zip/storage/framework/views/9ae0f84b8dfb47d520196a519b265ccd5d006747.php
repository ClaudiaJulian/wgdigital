<?php $__env->startSection('content'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

    <section class="white">
        <div class="">
            <ul class="nav-menu">                                   
                <li><a href="/item">Home</a></li>         
                <li><a href="/guardarropa">Mi Guardarropa</a></li>                
                <li><a href="/outfit">Mis Looks</a></li>            
                <li><a href="/producto/shop">Shop</a></li>
                <li><a href="/guardarropa">Ayuda</a></li>                    
            </ul>  
        </div>
    </section>
       
    <section class="principal">
        <form method="POST" id="nuevo" action="" name="nuevo" style="text-align: center;" enctype="multipart/form-data"> 
        <?php echo csrf_field(); ?>  
            <div class="formCreate">
                <ul class="indexColumn cajaCreate">
                    <li class="imgInfoCont">
                        <img class="imgInfo" src=<?php echo e(asset('/0_Item_Create.jpg')); ?>  alt="wGlam">                     
                    </li>
                    </li>
                        <label for="img"></label>
                        <img type="file" class="preview itemShow" style="display:none;" id="preview"  alt="wGlam">   
                        <input type="file" class="imgup" name="img" id="img" value="">
                    </li>
                    
                </ul>
                 
                <div class="indColumn">
                    <ul class="errors">
                        <?php if($errors->all()): ?><li> Faltan completar campos.</li> <?php endif; ?>        
                        
                    </ul>
                    <li> 
                        <p class="info"></p>  
                    </li>
                    <ul>
                        <li>
                            <label for="name"></label>
                            <input type="text" class="inputCreate" name="name" placeholder="Nombre" id="name" value=<?php echo e(old('name')); ?> >
                        </li>
                        <li>    
                            <label for="brand"></label>
                            <input type="text" class="inputCreate" name="brand" placeholder="Marca" id="brand" value=<?php echo e(old('brand')); ?>>
                        </li>     
                        <li>
                            <label for="categoria"></label>
                            <select name="categoria" id="mySelect" class="categoria inputCreate" type="number">
                            <option selected disabled> Categoría</option>
                            <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                            <option value=<?php echo e($cat['id']); ?> <?php echo e(((int)old('categoria') === $cat['id'])? 'selected':''); ?>><?php echo e($cat['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </li>
                        <li class="printed">
                            <label for="printed"></label>
                            <select name="printed" type="number" class="inputCreate">
                            <option selected disabled>Estampado</option>
                            <?php $__currentLoopData = $estampado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                            <option value=<?php echo e($e['id']); ?> <?php echo e(((int)old('printed') === $e['id'])? 'selected':''); ?>><?php echo e($e['nombre']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </li>
                          
                        <li class="colored">                            
                            <label for="colored"></label>
                            <select name="colored" type="number" class="inputCreate">
                            <option selected disabled>Color</option>
                            <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                            <option value=<?php echo e($col['id']); ?> <?php echo e(((int)old('colored') === $col['id'])? 'selected':''); ?>><?php echo e($col['nombre']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </li>
                        <li class="form">
                            <label  for="form"></label>
                            <select  name="form" type="number" id="form" class="inputCreate refForm">
                            <option selected disabled>Forma</option>
                            <?php $__currentLoopData = $forma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                            <option value=<?php echo e($f['id']); ?> <?php echo e(((int)old('form') === $f['id'])? 'selected':''); ?>><?php echo e($f['nombre']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </li>
                        <li class="length">
                            <label for="length"></label>
                            <select name="length" type="number" class="inputCreate refLen">
                            <option selected disabled>Largo</option>
                            <?php $__currentLoopData = $largo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                            <option value=<?php echo e($l['id']); ?> <?php echo e(((int)old('length') === $l['id'])? 'selected':''); ?>><?php echo e($l['nombre']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </li>
                        <li class="tipo_w">
                            <label for="tipo_w"></label>
                            <select name="tipo_w" type="number" class="inputCreate">
                            <option selected disabled>Tipo de Guardarropa</option>
                            <?php $__currentLoopData = $wardrobe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                            <option value=<?php echo e($w['id']); ?> <?php echo e(((int)old('tipo_w') === $w['id'])? 'selected':''); ?>><?php echo e($w['nombre']); ?></option>                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </li>    
                        <li>
                            <?php if(Auth::user()->id === 1): ?>   
                                <label for="body"></label>
                                <select name="body" type="number" class="inputCreate">
                                <option selected disabled>Forma de Cuerpo</option>
                                <?php $__currentLoopData = $cuerpo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                                <option value=<?php echo e($c['id']); ?> <?php echo e(((int)old('body') === $c['id'])? 'selected':''); ?>><?php echo e($c['nombre']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>            
                            <?php endif; ?>   
                        </li>
                        
                        <button type="submit" class="botonGral" name="button">Grabar</button>
                        
                    </ul>
                </div>                                        
            </div>           
        </form>
       
    </section>

<script rel="javascript" type="text/javascript" src="../js/wglam.js"></script> 


<?php $__env->stopSection(); ?>




<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>