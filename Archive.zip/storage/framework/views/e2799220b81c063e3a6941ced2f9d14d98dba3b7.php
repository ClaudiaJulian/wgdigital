<?php $__env->startSection('content'); ?>
<ul class="errors">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>


<section class="white">
    <div class="">
        <ul class="nav-menu">                                   
            <li><a href="/item">Home</a></li>         
            <li><a href="/guardarropa">Mi Guardarropa</a></li>                
            <li><a href="/outfit">Mis Looks</a></li>            
            <li><a href="/producto/shop">Shop</a></li>
            <li><a href="/guardarropa">Ayuda</a></li>                    
        </ul>  
    </div>


    <div class="BannerPerfil">
        <?php if($msgFaltaCuerpo !== "OK"): ?>
        <p style="background-color:red;color:white"> <?php echo e($msgFaltaCuerpo); ?> </p>
        <?php endif; ?>
    </div>
</section>

<section>    
    <div class="secAb"> 
        <?php $__currentLoopData = $ab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <ul> 
            <li class="detailAbName"> <?php echo e($a->nombre); ?>  |  <?php echo e($a->consultas===1?$a->consultas.' consulta':$a->consultas.' consultas'); ?></li> 
            <article class="detailAb" style="display:none;">
                <li > <?php echo e($a->capacidad); ?> Items</li>
                <li > <?php echo e($a->outfit); ?> Looks</li>
                <li > <?php echo e($a->itemOutfit); ?> Item/Look</li>
                <li > <?php echo e($a->consultas); ?> Consultas</li>
                <li class="botonAbPr"><a href=""><?php echo e($a->precio === 0? 'free':$a->precio); ?><?php echo e($a->precio === 0? '':' $/mes'); ?> </a></li>
            </article>       
        </ul> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </div>    

<section class="secPerfil" >
        <article class="SecDetailPerfil">            
            <h2><?php echo e(Auth::user()->name); ?> Plan <?php echo e(Auth::user()->abono); ?></h2>
            <?php $__currentLoopData = $ab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($a->id === Auth::user()->abono): ?>
                    <p><?php echo e($g); ?> de <?php echo e($a->capacidad); ?> Items  restan <?php echo e(( $a->capacidad - $g)); ?> Items </p>
                    <p><?php echo e($out); ?> de <?php echo e($a->outfit); ?> Oufits restan <?php echo e(($a->outfit - $out)); ?> Outfits </p> 
                    <p><?php echo e($a->consultas); ?> consulta personalizada</p>
                    <p><?php echo e($a->itemOutfit); ?> Items/Outfit</p> 
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          
        </article>
        <article>
            <div class="index">
                <a class="botonGral" href="/producto/shop">UpGrade</a> 
            </div>    
        </article>
</section>


<section class="secForma" >
        <article class="secFormaOption">
            <h2>Forma de Cuerpo</h2>
            <form method="POST" class="formaSelect" id="cuerpo" action="" name="cuerpo" style="text-align: center;" enctype="multipart/form-data"> 
                <?php echo csrf_field(); ?> 
                <?php echo method_field('put'); ?> 
                <article class="" >
                    <label for="body"></label>
                        <select  name="body" id="formaCuerpo" class="formaCuerpo" type="number">
                            <option selected disabled>Seleccionar Tipo de Cuerpo</option>
                            <?php $__currentLoopData = $cuerpo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                                <option value=<?php echo e($c['id']); ?> <?php echo e((Auth::user()->b_shape === $c['id'])?'selected':''); ?>><?php echo e($c['nombre']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                </article>
                <article>
                        <button type="submit" class="botonGral">Guardar</button> 
                </article>              
            </form>
        </article>

        <div class="index cajaForma">
            <div class="infoForma">
                    <ul style="height:100%;">
                        <li class="textCuerpo">La forma de tu cuerpo está determinada por tus Hombros, Busto, Cintura y Caderas</li>
                        <li class="textCuerpo1">Por eso la forma de las prendas es muy importante para estilizar la figura.</li>
                    </ul>
            </div>
            <article class="cajaImgCuerpo">
                <img class="imgCuerpo" src="/image/cuerpo/img_generico.jpg" alt="imagen-shape">
            </article>
        </div>
</section>    


<section class="space secPerfil">
        <article class="SeccionIntroWel">
            <h2>Editar Perfil</h2>
            <form method="POST" action="">
                <?php echo csrf_field(); ?> 
                <?php echo method_field('put'); ?>                   
    
                <article class="form-group form-group2">
                    <label for="name" class=""><?php echo e(__('Nombre ')); ?></label>
                    <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(Auth::User()->name); ?>">
                </article>
    
                <article class="form-group form-group2">
                    <label for="email" class=""><?php echo e(__('E-Mail ')); ?></label>
                    <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(Auth::User()->email); ?>" required>
                                    
                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                </article>
    
                <article class="form-group form-group2">
                    <label for="password" class=""><?php echo e(__('Password ')); ?></label>
                    <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
    
                    <?php if($errors->has('password')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                </article>
    
                <article class="form-group form-group2">
                    <label for="password-confirm" class=""><?php echo e(__('Confirme Password ')); ?></label>
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                </article>
        
                <article class="form-group">
                    <button type="submit" class="botonGral">
                        <?php echo e(__('Editar')); ?>

                    </button><br>
                </article>
    
            </form>
        </article>
    </section>    
</section>

<script rel="javascript" type="text/javascript" src="../../js/wglam.js"></script> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>