<?php $__env->startSection('content'); ?>


<section class="white">
        <ul class="nav-menu">          
            <li><a href="/item/create"> Item </a></li>    
            <li><a href="/categoria">Categorías</a></li>
            <li><a href="/formula">Formulas</a></li>
            <li><a href="/abono">Abonos</a></li>
            <li><a href="/adm/user">Roles</a></li>
            <li><a href="/categoria">Mensajes</a></li>
            <li><a href="/categoria">Gestion</a></li>      
        </ul>
    </section> 

<section class="principal">        

    <ul class="errors">
        <?php if($errors->all()): ?><li> Te falta elegir un mail.</li> <?php endif; ?>        
    </ul> 

    <article class="index">
        <p class="" style="margin:0px 20px;"> 1. Crear Usuario</p><p class="" style="margin:0px 20px;">2. Cambiar Rol</p>
    </article>   

    <article style="margin-top:20px;">
        <h1>Administradores</h1>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
            <?php if($adm->role === "adm"): ?> 
            <ul class="index" style="border-bottom:solid white 2px;margin:5px;"> 
                <li class="">  <h3> <?php echo e($adm['id']); ?> </h3>  </li>   
                <li class="">  <h4> <?php echo e($adm['name']); ?> </h4> </li> 
                <li class="">  <h4> <?php echo e($adm['email']); ?> </h4> </li> 
                <li><form method="POST" id="cambioRol" action="/adm/user/change/<?php echo e($adm['id']); ?>" name="cambioRol" style="text-align: center;" enctype="multipart/form-data"> 
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?> 
                        <label for="role"></label>
                        <select name="role" id="role" class="role" type="text">
                            <option value="adm" <?php echo e($adm['role'] === 'adm'?'selected':''); ?>> Administrador</option>
                            <option value="seller" <?php echo e($adm['role'] === 'seller'?'selected':''); ?>> Seller </option>
                            <option value="null" <?php echo e($adm['role'] === 'null'?'selected':''); ?>> Usuario </option>
                            <option value="off" <?php echo e($adm['role'] === 'off'?'selected':''); ?>> Inactivo </option>
                        </select>                        
                        <button type="submit" class="">Cambiar</button>
                    </form>                             
                </li>
            </ul>
            <?php endif; ?>         
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
        <div style="width:200px;margin:5px;background-color:white;">
                    <form method="POST" id="rolUser" action="" name="rolUser" style="text-align: center;" enctype="multipart/form-data"> 
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?> 
                            <label for="adm"></label>
                            <select name="adm" id="adm" class="adm" type="number">
                                <option selected disabled> Seleccionar Mail</option>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value=<?php echo e($us['id']); ?> <?php echo e($us['role'] === 'adm' || $us['role'] === 'seller' || $us['role'] === 'off' ?'disabled':''); ?>><?php echo e($us->email); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>                            
                            <button type="submit" class="botonGral">Grabar Administrador</button>
                    </form>    
        </div>                  
    </article> 

    <article style="margin-top:20px;">
            <h1>Sellers</h1>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                <?php if($seller->role === "seller"): ?> 
                <ul class="index" style="border-bottom:solid white 2px;margin:5px;"> 
                    <li class="">  <h3> <?php echo e($seller['id']); ?> </h3>  </li>   
                    <li class="">  <h4> <?php echo e($seller['name']); ?> </h4> </li> 
                    <li class="">  <h4> <?php echo e($seller['email']); ?> </h4> </li> 
                    <li><form method="POST" id="cambioRol" action="/adm/user/change/<?php echo e($seller['id']); ?>" name="cambioRol" style="text-align: center;" enctype="multipart/form-data"> 
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?> 
                            <label for="role"></label>
                            <select name="role" id="role" class="role" type="text">
                                <option value="adm" <?php echo e($seller['role'] === 'adm'?'selected':''); ?>> Administrador</option>
                                <option value="seller" <?php echo e($seller['role'] === 'seller'?'selected':''); ?>> Seller </option>
                                <option value="null" <?php echo e($seller['role'] === 'null'?'selected':''); ?>> Usuario </option>
                                <option value="off" <?php echo e($seller['role'] === 'off'?'selected':''); ?>> Inactivo </option>
                            </select>                        
                            <button type="submit" class="">Cambiar</button>
                        </form>                             
                    </li> 
                </ul>
                <?php endif; ?>         
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
            <div style="width:200px;margin:5px;background-color:white;">
                    <form method="POST" id="rolUser" action="" name="rolUser" style="text-align: center;" enctype="multipart/form-data"> 
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?> 
                        <label for="seller"></label>
                        <select name="seller" id="seller" class="seller" type="number">
                            <option selected disabled> Seleccionar Mail</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value=<?php echo e($us['id']); ?> <?php echo e($us['role'] === 'seller' || $us['role'] === 'adm' || $us['role'] === 'off'?'disabled':''); ?>><?php echo e($us->email); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>                        
                        <button type="submit" class="botonGral">Grabar Seller</button>
                    </form>     
            </div>                  
        </article> 
        <article style="margin-top:20px;">
                <h1>Inactivos</h1>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                    <?php if($us->role === "off"): ?> 
                    <ul class="index" style="border-bottom:solid white 2px;margin:5px;"> 
                        <li class="">  <h3> <?php echo e($us['id']); ?> </h3>  </li>   
                        <li class="">  <h4> <?php echo e($us['name']); ?> </h4> </li> 
                        <li class="">  <h4> <?php echo e($us['email']); ?> </h4> </li> 
                        <li><form method="POST" id="cambioRol" action="/adm/user/change/<?php echo e($us['id']); ?>" name="cambioRol" style="text-align: center;" enctype="multipart/form-data"> 
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?> 
                                <label for="role"></label>
                                <select name="role" id="role" class="role" type="text">
                                    <option value="adm" <?php echo e($us['role'] === 'adm'?'selected':''); ?>> Administrador</option>
                                    <option value="seller" <?php echo e($us['role'] === 'seller'?'selected':''); ?>> Seller </option>
                                    <option value="null" <?php echo e($us['role'] === 'null'?'selected':''); ?>> Usuario </option>
                                    <option value="off" <?php echo e($us['role'] === 'off'?'selected':''); ?>> Inactivo </option>
                                </select>                        
                                <button type="submit" class="">Cambiar</button>
                            </form>                             
                        </li>
                    </ul>
                    <?php endif; ?>         
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                <div style="width:200px;margin:5px;background-color:white;">
                            <form method="POST" id="rolUser" action="" name="rolUser" style="text-align: center;" enctype="multipart/form-data"> 
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?> 
                                    <label for="off"></label>
                                    <select name="off" id="off" class="off" type="number">
                                        <option selected disabled> Seleccionar Mail</option>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value=<?php echo e($us['id']); ?> <?php echo e($us['role'] === 'off'?'disabled':''); ?>><?php echo e($us->email); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>                            
                                    <button type="submit" class="botonGral">Grabar Inactivo</button>
                            </form>    
                </div>                  
            </article>    

    </section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>