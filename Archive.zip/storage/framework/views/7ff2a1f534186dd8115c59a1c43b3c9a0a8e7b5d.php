<?php if($paginator->hasPages()): ?>

    <ul class="index" role="navigation">
       
        
       
        
        <?php if($paginator->onFirstPage()): ?>
            <li class="page-item disabled" aria-disabled="true">
                <span class="page-link" style="font-size:0.8em;color:grey;"><?php echo app('translator')->getFromJson('pagination.previous'); ?></span>
            </li>
        <?php else: ?>
            <li class="page-item">
                <a class="page-link" style="font-size:0.8em;" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev"><?php echo app('translator')->getFromJson('pagination.previous'); ?></a>
            </li>
        <?php endif; ?>

        <li style="font-size:0.8em;margin-left:30px;margin-right:30px;"> Outfit: <?php echo e($paginator->currentPage()); ?></li>

        
        <?php if($paginator->hasMorePages()): ?>
            <li class="page-item">
                <a class="page-link" style="font-size:0.8em;" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next"><?php echo app('translator')->getFromJson('pagination.next'); ?></a>
            </li>
        <?php else: ?>
            <li class="page-item disabled" aria-disabled="true">
                <span class="page-link" style="font-size:0.8em;color:grey;"><?php echo app('translator')->getFromJson('pagination.next'); ?></span>
            </li>
        <?php endif; ?>
    </ul>
<?php endif; ?>
