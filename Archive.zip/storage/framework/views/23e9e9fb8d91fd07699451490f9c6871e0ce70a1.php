<?php $__env->startSection('content'); ?>

<ul class="errors">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

<section>
    <div class="index">          
        <p ><a class="links" href="/item"> Item </a></p>    
        <p ><a class="links" href="/categoria">Categorías</a></p>
        <p ><a class="links" href="/formula">Algoritmos</a></p>
    </div>

    <form method="POST" id="nuevo" action="" name="nuevo" style="text-align: center;" enctype="multipart/form-data"> 
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>   
        <ul>
            <div>    
                <label for="name">Name</label>
                <input type="text" name="name" id="name" value="<?php echo e($categoria['name']); ?>" >
            </div>
        </ul>
        <button type="submit" name="button">Guardar</button>
    </form>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>