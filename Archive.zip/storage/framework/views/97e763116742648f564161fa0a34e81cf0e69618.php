<?php $__env->startSection('content'); ?>

       
    <section>         
        <div class="white">
            <ul class="nav-menu">                   
                <li><a href="/item">Home</a></li>         
                <li><a href="/guardarropa">Guardarropa</a></li>                
                <li><a href="/outfit">Looks</a></li>
                <li><a href="/guardarropa">Assistant</a></li>
                <li><a href="/producto/shop">Shop</a></li>
            </ul>
        </div>
    </section>    
    <section class="principal">
        <form method="POST" id="nuevo" action="" name="nuevo" style="text-align: center;" enctype="multipart/form-data"> 
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?> 

            <div class="formCreate">
                <ul class="indColumn"> 
                    <div class="indColumn cajaItemShow">
                        <label for="img"></label>                           
                        <img class="itemShow" src="<?php echo e(asset($item->photo)); ?>">
                        <input type="file" name="img" id="img" value="">
                    </div>    
                </ul>  
                <ul class="detalle">
                    <li class="editItem" >
                        <label for="name">Nombre:</label>
                        <input type="text" name="name" id="name" value="<?php echo e($item['name']); ?>" >
                    </li>
                    <li class="editItem">
                        <label for="brand">Marca:</label>
                        <input type="text" name="brand" id="brand" value="<?php echo e($item['brand']); ?>" >
                    </li>
                    <li class="editItem">
                        <label for="categoria">Categoría:</label>
                            <select name="categoria" type="number">
                                <option disabled selected>Select</option>
                                    <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                                        <option value=<?php echo e($cat['id']); ?> <?php echo e(($item['categoria_id']===$cat['id']) ? 'selected' : ''); ?>><?php echo e($cat['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </li>                    
                    <li class="editItem">
                        <label for="printed">Estampado:</label>
                            <select name="printed" type="number">
                                <option disabled selected>Select</option>
                                    <?php $__currentLoopData = $estampado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                                        <option value=<?php echo e($e['id']); ?> <?php echo e(($item['printed']===$e['id']) ? 'selected' : ''); ?>><?php echo e($e['nombre']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </li>
                    <li class="editItem">
                        <label for="colored">Color:</label>
                            <select name="colored" type="number">
                                <option disabled selected>Select</option>
                                    <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                                        <option value=<?php echo e($col['id']); ?> <?php echo e(($item['colored']===$col['id']) ? 'selected' : ''); ?>><?php echo e($col['nombre']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </li>
                    <li class="editItem">
                            <label for="form">Forma:</label>
                                <select name="form" type="number">
                                    <option disabled selected>Select</option>
                                        <?php $__currentLoopData = $forma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                                            <option value=<?php echo e($f['id']); ?> <?php echo e(($item['form']===$f['id']) ? 'selected' : ''); ?>><?php echo e($f['nombre']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                    </li>
                    <li class="editItem">
                        <label for="length">Largo:</label>
                            <select name="length" type="number">
                                <option disabled selected>Select</option>
                                    <?php $__currentLoopData = $largo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                                        <option value=<?php echo e($l['id']); ?> <?php echo e(($item['length']===$l['id']) ? 'selected' : ''); ?>><?php echo e($l['nombre']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>        
                    </li>
                    <li class="editItem">
                        <label for="tipo_w">Guardarropa:</label>
                            <select name="tipo_w" type="number">
                            <option disabled selected>Select</option>
                                    <?php $__currentLoopData = $wardrobe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                                    <option value=<?php echo e($w['id']); ?> <?php echo e(($item['tipo_w']=== $w['id']) ? 'selected' : ''); ?>><?php echo e($w['nombre']); ?></option>                            
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </li>       
                    <?php if(Auth::user()->id === 1): ?>
                    <li class="editItem">
                        <label for="body">Body Shape:</label>
                            <select name="body" type="number">
                                <option disabled selected>Select</option>
                                    <?php $__currentLoopData = $cuerpo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                                        <option value=<?php echo e($c['id']); ?> <?php echo e(($item['body']===$c['id']) ? 'selected' : ''); ?>><?php echo e($c['nombre']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </li>                                         
                    <?php endif; ?>
                    <li class="index">
                    <button class="botonGral" type="submit">Guardar</button>
                    </li>                                
                </ul>                
            </form>
        </div>
    </section>          


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>