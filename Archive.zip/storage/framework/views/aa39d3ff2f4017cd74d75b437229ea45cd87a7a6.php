<?php $__env->startSection('content'); ?>

<ul class="errors">
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<section class="white">
    <ul class="nav-menu">          
        <li><a href="/item/create"> Item </a></li>    
        <li><a href="/categoria">Categorías</a></li>
        <li><a href="/formula">Formulas</a></li>
        <li><a href="/abono">Abonos</a></li>
        <li><a href="/adm/user">Roles</a></li>
        <li><a href="/categoria">Mensajes</a></li>
        <li><a href="/categoria">Gestion</a></li>      
    </ul>
</section>

<section class="principal">

<div class="index"> 
    <ul class="index">
        <li> Columnar : <?php echo e($qBody2); ?> </li>
        <li> Rectangular :<?php echo e($qBody3); ?> </li>
        <li> Triangular : <?php echo e($qBody4); ?></li>
        <li> Cono : <?php echo e($qBody5); ?> </li>
        <li> Oval : <?php echo e($qBody6); ?> </li>
        <li> Reloj de Arena : <?php echo e($qBody1); ?> </li>
    </ul>    
</div>

<table class="index">
        <tr>                
            <th>Cuerpo</th>
            <th>Categ.</th>
            <th>Forma</th>
            <th>Est.</th>
            <th>Color</th>
            <th>Largo</th>
            <th>Categ.</th>
            <th>Forma</th>
            <th>Est.</th>
            <th>Color</th>
            <th>Largo</th>
            <th>Categ.</th>
            <th>Forma</th>
            <th>Est.</th>
            <th>Color</th>
            <th>Largo</th>
            <th>Modificar</th>
        </tr>

    <?php $__currentLoopData = $formulas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr class="FondoTablaProducto" style="text-align:center;font-size:0.8em;"> 
        
        <td><p style="margin:5px;color:blue;"><?php echo e($formula->cuerpo); ?></p> </td>         
        <td><p style="margin:5px;color:red;"><?php echo e($formula->categoria_1); ?></p>  </td>
        <td>
            <?php $__currentLoopData = $forma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                <?php if($formula->form_1 === $f->id): ?>  
                    <p style="margin:5px"><?php echo e($f->nombre); ?></p>  
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td>
            <?php $__currentLoopData = $estampado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                <?php if($formula->printed_1 === $e->id): ?>  
                    <p style="margin:5px"><?php echo e($e->nombre); ?></p>  
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td>
            <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                <?php if($formula->colored_1 === $col->id): ?>  
                    <p style="margin:5px"><?php echo e($col->nombre); ?></p>  
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td>   
            <?php $__currentLoopData = $largo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                <?php if($formula->length_1 === $l->id): ?>  
                    <p style="margin:5px"><?php echo e($l->nombre); ?></p>  
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td>
            <p style="margin:5px;color:red;"><?php echo e($formula->categoria_2); ?></p> 
        </td>
        <td>
        <?php $__currentLoopData = $forma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
            <?php if($formula->form_2 === $f->id): ?>  
                <p style="margin:5px"><?php echo e($f->nombre); ?></p>  
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>       
        <td>
        <?php $__currentLoopData = $estampado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
            <?php if($formula->printed_2 === $e->id): ?>  
                <p style="margin:5px"><?php echo e($e->nombre); ?></p>  
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td>       
        <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
            <?php if($formula->colored_2 === $col->id): ?>  
                <p style="margin:5px"><?php echo e($col->nombre); ?></p>  
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
        </td>
        <td>           
        <?php $__currentLoopData = $largo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
            <?php if($formula->length_2 === $l->id): ?>  
                <p style="margin:5px"><?php echo e($l->nombre); ?></p>  
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td>
            <p style="margin:5px;color:red;"><?php echo e($formula->categoria_3); ?></p> 
        </td>
        <td>
        <?php $__currentLoopData = $forma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
            <?php if($formula->form_3 === $f->id): ?>  
                <p style="margin:5px"><?php echo e($f->nombre); ?></p>  
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td>               
        <?php $__currentLoopData = $estampado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
            <?php if($formula->printed_3 === $e->id): ?>  
                <p style="margin:5px"><?php echo e($e->nombre); ?></p>  
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td>               
        <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
            <?php if($formula->colored_3 === $col->id): ?>  
                <p style="margin:5px"><?php echo e($col->nombre); ?></p>  
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td>                   
        <?php $__currentLoopData = $largo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
            <?php if($formula->length_3 === $l->id): ?>  
                <p style="margin:5px"><?php echo e($l->nombre); ?></p>  
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>               
        <td>
            <p><a class="links"  href="/formula/<?php echo e($formula->id); ?>/edit"  style="color:green;margin:5px;font-size:0.8em;">Editar</a></p>
            <p><a class="links" href="/formula/<?php echo e($formula->id); ?>/delete"  style="color:green;margin:5px;font-size:0.8em;">Eliminar</a></p>        
        </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<div class="index">
    <p class="white"><a class="links" href="/formula/create">Nueva Formula</a></p>
</div>
</section>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>