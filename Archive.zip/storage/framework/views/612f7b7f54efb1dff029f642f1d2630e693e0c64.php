<?php $__env->startSection('content'); ?>
     
    <section>
        <div class="white">
            <ul class="nav-menu">                                   
                <li><a href="/item">Home</a></li>         
                <li><a href="/guardarropa">Mi Guardarropa</a></li>                
                <li><a href="/outfit">Mis Looks</a></li>            
                <li><a href="/producto/shop">Shop</a></li>
                <li><a href="/guardarropa">Ayuda</a></li>                    
            </ul>  
        </div>
    </section>    
    <section class="principal">
            
        <div class="formCreate">
            <ul class="indColumn cajaItemShow">
                <li>
                    <a>                            
                    <img class="itemShow" src="<?php echo e(asset($item->photo)); ?>">
                    </a>
                </li>   
                <div class="index">
                    <p class="itemCat"><?php echo e($item->categoria->name); ?></p>  
                    <p class="itemName"><?php echo e($item['name']); ?></p>
                </div>                
            </ul>     
            <article class="detalle">
                <ul class="indColumn">
                    <div class="detalleInfo">    
                        <li class="detName">Marca:</li>
                        <li class="detValue"><?php echo e($item->brand); ?></li>
                    </div>
                    <div class="detalleInfo">
                        <li class="detName">Estampado:</li>
                        <li class="detValue"><?php echo e($item->estampado->nombre); ?></li>
                    </div>
                    <div class="detalleInfo">
                        <li class="detName">Color:</li>
                        <li class="detValue"><?php echo e($item->color->nombre); ?></li>
                    </div>    
                    <?php if($item->categoria_id < 6): ?>
                    <div class="detalleInfo">
                        <li class="detName">Forma:</li>
                        <li class="detValue"><?php echo e($item->forma->nombre); ?></li>
                    </div>
                    <div class="detalleInfo">
                        <li class="detName">Largo:</li>    
                        <li class="detValue"><?php echo e($item->largo->nombre); ?></li>
                    </div>
                    <?php endif; ?>
                    <div class="detalleInfo">
                        <li class="detName">Estación:</li>
                        <li class="detValue"><?php echo e($item->wardrobe->nombre); ?></li>
                    </div>    

                    <?php if(Auth::user()): ?>
                    <?php if($item['user_id']!== 1 || Auth::user()-> id === 1): ?>
                        <button class="botonGral"><a href="/item/<?php echo e($item->id); ?>/edit">Editar</a></button>
                    <?php endif; ?>
                    <?php endif; ?> 
                </ul>
            </article>           
            
        </div>
    </section>


          
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>