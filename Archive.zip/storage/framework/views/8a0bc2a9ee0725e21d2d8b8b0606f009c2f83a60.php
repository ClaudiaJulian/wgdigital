<?php $__env->startSection('content'); ?>


<section class="white">
        <ul class="nav-menu">          
            <li><a href="/item/create"> Item </a></li>    
            <li><a href="/categoria">Categorías</a></li>
            <li><a href="/formula">Formulas</a></li>
            <li><a href="/abono">Abonos</a></li>
            <li><a href="/adm/user">Roles</a></li>
            <li><a href="/categoria">Mensajes</a></li>
            <li><a href="/categoria">Gestion</a></li>      
        </ul>
    </section> 

<section class="principal">        
    <div style="margin-top:20px;">
        <ul class="index">  
        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style="border:solid white 1px;margin:5px;">    
            <li class="">  
                <a class="links" href="categoria/<?php echo e($categoria->id); ?>">
                <h3> - <?php echo e($categoria['id']); ?> - </h3>    
                <h4> <?php echo e($categoria['name']); ?> </h4>        
                </a>

            
                <div class="index">
                    <p ><a class="links" href="/categoria/<?php echo e($categoria->id); ?>/edit">Editar</a></p>
                    <p ><a class="links" href="/categoria/<?php echo e($categoria->id); ?>/delete">Eliminar</a></p>        
                </div>
            

            </li>
        </div>     
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div style="border:solid pink 1px;margin:5px;background-color:white;">
            <li class="">  
                <a class="links" href="categoria/create">
                <h4> Nueva Categoria </h4></a>
            </li>   
        </div>   
        </ul>          
    </div> 

   
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>