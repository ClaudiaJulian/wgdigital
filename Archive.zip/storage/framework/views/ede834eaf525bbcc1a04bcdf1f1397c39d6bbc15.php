<?php $__env->startSection('content'); ?>


<section class="content">
    <article> 
        <h2 class="titulo">>Crea tu Conjunto</h2>
    </article> 
    
    <div class="index">
        <p><a class="links" href="/item">Items</a></p>
        <p><a class="links" href="/categoria">Categorias</a></p>
    </div>

    <ul class="container">

        <li class="column1">                                
            <?php if($item->categoria_id === 1): ?>
            <?php $__currentLoopData = $formulas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $for): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->form === $for->form_1 && $item->printed === $for->printed_1 && $item->colored === $for->colored_1 && $item->length === $for->length_1): ?>
                    <img class="topFor" src="<?php echo e(asset($item->photo)); ?>" alt="">
                <?php endif; ?>            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
           
            <?php $__currentLoopData = $miguardarropa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($b->categoria_id === 1): ?>
                    <?php $__currentLoopData = $formulas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $for): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($b->form === $for->form_1 && $b->printed === $for->printed_1 && $b->colored === $for->colored_1 && $b->length === $for->length_1): ?>
                        <img class="topFor" src="<?php echo e(asset($b->photo)); ?>" alt="">
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>       

            <?php if($item->categoria_id === 2): ?>
            <img class="bottomFor" src="<?php echo e(asset($item->photo)); ?>" alt="BOTTOM">                              
            <?php else: ?>
            <?php $__currentLoopData = $miguardarropa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($b->categoria_id === 2): ?>
                    <?php $__currentLoopData = $formulas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $for): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($b->form === $for->form_2 && $b->printed === $for->printed_2 && $b->colored === $for->colored_2 && $b->length === $for->length_2): ?>
                        <img class="bottomFor" src="<?php echo e(asset($b->photo)); ?>" alt="BOTTOM">
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>       
        </li>

        <li class="column2">
            <?php if($item->categoria_id === 4): ?>
            <img class="outFor" src="<?php echo e(asset($item->photo)); ?>" alt="OUTWEAR">
            <?php else: ?>
            <?php $__currentLoopData = $miguardarropa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($b->categoria_id === 4): ?>
                <?php $__currentLoopData = $formulas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $for): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($b->form === $for->form_3 && $b->printed === $for->printed_3 && $b->colored === $for->colored_3 && $b->length === $for->length_3): ?>
                    <img class="outFor" src="<?php echo e(asset($b->photo)); ?>" alt="OUTWEAR">
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>       

        <div>
            <label for="img"></label>
            <p class="boxacc"><img class="bag" id="6" alt="Click to Choose BAG"></p>
        </div>  

        <div>
            <label for="img"></label>
             <p class="boxacc"><img class="shoes" id="5" alt="Click to Choose SHOES"></p> 
        </div>                  
        <!-- <img class="other" src="" alt="Choose OTHER">  -->
        </li>              
 
    </ul>
    
    <script src="../js/wglam.js"></script>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>