<?php $__env->startSection('content'); ?>


<section class="white">
        <ul class="nav-menu">          
            <li><a href="/item/create"> Item </a></li>    
            <li><a href="/categoria">Categorías</a></li>
            <li><a href="/formula">Formulas</a></li>
            <li><a href="/abono">Abonos</a></li>
            <li><a href="/adm/user">Roles</a></li>
            <li><a href="/categoria">Mensajes</a></li>
            <li><a href="/categoria">Gestion</a></li>      
        </ul>
    </section> 

<section class="principal">        

    <ul class="errors">
        <?php if($errors->all()): ?><li> Completá todos los datos antes de grabar.</li> <?php endif; ?>   
    </ul> 

<article style="margin-top:20px;">
    <h1>Abonos</h1>
    <table class="index">
        <tr style="background-color:lightblue;">                
            <th style="font-size:0.8em;">Id</th>
            <th style="font-size:0.8em;">Nombre</th>
            <th style="font-size:0.8em;">Estrellas</th>
            <th style="font-size:0.8em;">Guardarropa</th>
            <th style="font-size:0.8em;">Capacidad</th>
            <th style="font-size:0.8em;">Outfit</th>
            <th style="font-size:0.8em;">Item/Out</th>
            <th style="font-size:0.8em;">p_mes</th>
            <th style="font-size:0.8em;">p_sem</th>
            <th style="font-size:0.8em;">p_anual</th>
            <th style="font-size:0.8em;">Consultas</th>
            <th style="font-size:0.8em;">Modificar</th>
        </tr>

        <?php $__currentLoopData = $abonos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
        <form method="POST" id="cambiarAb" action="/abono/<?php echo e($ab['id']); ?>/edit" name="cambiarAb" style="text-align: center;" enctype="multipart/form-data"> 
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?> 
            <tr style="background-color:azure;">            
                <td ><?php echo e($ab['id']); ?> </td>
                <td >
                    <label for="nombre"></label>
                    <input type="text" name="nombre" style="width:70px;" value=<?php echo e($ab['nombre']); ?>> 
                </td> 
                <td>
                    <label for="estrellas"></label>
                    <input type="number" name="estrellas" style="width:70px;" value=<?php echo e($ab['estrellas']); ?>> 
                </td> 
                <td>
                    <label for="guardarropa"></label>  
                    <input type="number" name="guardarropa" style="width:70px;" value=<?php echo e($ab['guardarropa']); ?>> 
                </td>
                <td>
                    <label for="capacidad"></label>    
                    <input type="number" name="capacidad" style="width:70px;" value=<?php echo e($ab['capacidad']); ?>> 
                </td> 
                <td>
                    <label for="outfit"></label>      
                    <input type="number" name="outfit" style="width:70px;" value=<?php echo e($ab['outfit']); ?>> 
                </td>
                <td>
                    <label for="itemOutfit"></label>        
                    <input type="number" name="itemOutfit" style="width:70px;" value=<?php echo e($ab['itemOutfit']); ?>> 
                </td>
                <td>
                    <label for="p_mes"></label>
                    <input type="number" name="p_mes" style="width:70px;" value=<?php echo e($ab['p_mes']); ?>> 
                </td> 
                <td>
                    <label for="p_sem"></label>
                    <input type="number" name="p_sem" style="width:70px;" value=<?php echo e($ab['p_sem']); ?>> 
                </td> 
                <td>
                    <label for="p_anual"></label>  
                    <input type="number" name="p_anual" style="width:70px;" value=<?php echo e($ab['p_anual']); ?>> 
                </td>                  
                <td>
                    <label for="consultas"></label>          
                    <input type="number" name="consultas" style="width:70px;" value=<?php echo e($ab['consultas']); ?>> 
                </td> 
                <td>
                    <button type="submit" style="width:70px;">Actualizar</button>
                    <a class="links" href="/abono/<?php echo e($ab->id); ?>/delete"  style="color:green;margin:5px;font-size:0.8em;width:70px;">Eliminar</a>
                </td> 
            </tr>       
        </form>    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>        
        
        
    <h1>Crear un Nuevo Abono</h1>    
        <div style="margin:5px;background-color:white;">
            <form method="POST" id="nuevoAb" action="/abono/create" name="nuevoAb" style="text-align: center;" enctype="multipart/form-data"> 
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?> 
                    <ul class="indColumn">
                        <div>
                            <label for="nombre">Nombre</label>
                            <input type="text" name="nombre" value="">
                        </div>
                        <div>
                            <label for="estrellas">Estrellas</label>
                            <input type="number" name="estrellas" value="">
                        </div>
                        <div>
                            <label for="p_mes">Precio Mes</label>
                            <input type="number" name="p_mes" value="">
                        </div>
                        <div>
                            <label for="p_sem">Precio Semestre</label>
                            <input type="number" name="p_sem" value="">
                        </div>
                        <div>
                            <label for="p_anual">Precio Anual</label>
                            <input type="number" name="p_anual" value="">
                        </div>
                        <div>
                            <label for="guardarropa">Guardarropa</label>
                            <input type="number" name="guardarropa" value="">
                        </div>
                        <div>
                            <label for="capacidad">Capacidad de Items</label>
                            <input type="number" name="capacidad" value="">
                        </div>
                        <div>
                            <label for="outfit">Cantidad de Outfits</label>
                            <input type="number" name="outfit" value="">
                        </div>
                        <div>
                            <label for="itemOutfit">Items / Outfit</label>
                            <input type="number" name="itemOutfit" value="">
                        </div>
                        <div>
                            <label for="consultas">Consultas</label>
                            <input type="number" name="consultas" value="">
                        </div>
                            
                            <button type="submit" class="botonGral">Grabar Nuevo Abono</button>
                    </ul>    
            </form>    
        </div>                  
    </article> 

    
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>