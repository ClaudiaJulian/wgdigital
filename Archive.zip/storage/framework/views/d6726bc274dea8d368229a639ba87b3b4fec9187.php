<?php $__env->startSection('content'); ?>

<ul class="errors">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>


<section class="white">
    <div class="">
        <ul class="nav-menu">                   
                <li><a href="/item">Home</a></li>         
                <li><a href="/guardarropa">Guardarropa</a></li>                                
                <li><a href="/outfit">Looks</a></li>
                
                <li><a href="/producto/shop"><strong>Shop</strong></a></li>
        </ul>
    </div>


    <div class="BannerPerfil">
        <h1></h1>
    </div>
</section>

<section>    
    <div class="secAb">
            <?php $__currentLoopData = $pk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <ul>
                <li class="detailAbName"> <?php echo e($k->nombre); ?> |  <?php echo e($k->items); ?> productos</li>
                <article class="detailAb" style="display:none;">
                    <li> <?php echo e($k->apariciones); ?> apariciones </li>
                    <li class="botonAbPr"><a href=""><?php echo e($k->v_mes === 0? 'free':$k->v_mes); ?><?php echo e($k->v_mes === 0? '':' $/mes'); ?> </a></li>
                </article>
            </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

        
<section class="secPerfil">
                <article class="SecDetailPerfil">            
                    <h2><?php echo e(Auth::user()->name); ?> Pack <?php echo e(Auth::user()->pack); ?></h2>
                    <p>5 Productos On Line</p>
                    <p>Presencia en Shop</p>           
                </article>
                <article>
                    <div class="index">
                        <button type="submit" class="botonGral">UpGrade</button> 
                    </div>    
                </article>
            </section>        
        
            <section class="secForma">
                <article class="producOn">
                    <h2 >PRODUCTOS ONLINE <strong class="cantProd"> <?php echo e(count($productos)); ?> </strong></h2>
                    <a class="botonGral"  href="../../producto/create"> + Nuevo Item </a>    
                </article>
                <article>    
                <article class="margin10">   
                    <div class="">
                        <?php if(isset($limite)): ?>
                            <p style="color:red;"><?php echo e($limite); ?></p>
                        <?php endif; ?>
                    </div>    
                    <ul class="index">
                        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li >  
                                <div class="cajaIndex">
                                    <a class="cajaImgIndex" href="/.../../producto/shop/<?php echo e($pro->id); ?>">
                                        <img class="imgIndex"" src="<?php echo e(asset($pro->photo)); ?>" alt="Icono de <?php echo e($pro->name); ?> ">         
                                    </a>
                
                                    <div class="index" style="padding: 5px;">
                                        <a class="links"> $ <?php echo e($pro->precio); ?> </a>
                                        <?php if($pro->on_off === 'on'): ?>
                                            <a class="links" href="/producto/add/<?php echo e($pro->id); ?>"> <?php echo e($pro->on_off); ?> </a>
                                        <?php endif; ?>
                                        <a class="links" href="../../producto/shop/<?php echo e($pro->id); ?>"> Info </a>
                                    </div>
                                </div>
                             </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>          
                </article> 
                </article>
</section>    
        
        
<section class="space secPerfil">
                <article class="SeccionIntroWel">
                    <h2>Editar Perfil</h2>
                    <form method="POST" action="">
                        <?php echo csrf_field(); ?> 
                        <?php echo method_field('put'); ?>                   
            
                        <article class="form-group form-group2">
                            <label for="name" class=""><?php echo e(__('Nombre ')); ?></label>
                            <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(Auth::User()->name); ?>">
                        </article>
            
                        <article class="form-group form-group2">
                            <label for="email" class=""><?php echo e(__('E-Mail ')); ?></label>
                            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(Auth::User()->email); ?>" required>
                                            
                            <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </article>
            
                        <article class="form-group form-group2">
                            <label for="password" class=""><?php echo e(__('Password ')); ?></label>
                            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
            
                            <?php if($errors->has('password')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </article>
            
                        <article class="form-group form-group2">
                            <label for="password-confirm" class=""><?php echo e(__('Confirme Password')); ?></label>
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                        </article>
                
                        <article class="form-group">
                            <button type="submit" class="botonGral">
                                <?php echo e(__('Editar')); ?>

                            </button><br>
                        </article>
            
                    </form>
                </article>
</section>    
</section>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>