<?php $__env->startSection('content'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<section class="white">    
    <div class="">
        <ul class="nav-menu">                                   
            <li><a href="/item">Home</a></li>         
            <li><a href="/guardarropa">Mi Guardarropa</a></li>                
            <li><a href="/outfit">Mis Looks</a></li>            
            <li><a href="/producto/shop">Shop</a></li>
            <li><a href="/guardarropa">Ayuda</a></li>                    
        </ul>  
     </div>
    
    <div class="BannerWardrobe">
        <?php if(isset($it) && isset($a)): ?>)
             <?php if($it === $a): ?>
                <p style="background-color:red;"> Llegaste a tus <?php echo e($a); ?> Items! </p>
            <?php else: ?>
                <p> Tus <?php if($it > 0): ?> <?php echo e($it); ?> <?php endif; ?> Items para todos tus Looks.</p>
            <?php endif; ?>
        <?php endif; ?>
        <?php if(!isset($it) && isset($a)): ?>)        
            <p> Subí nuestros items ó tus propias fotos.</p>
        <?php endif; ?>
        <?php if(isset($seller)): ?> <p style="background-color:red;"> <?php echo e($seller); ?>  </p> <?php endif; ?>
    </div> 
</section>

<section class="principal">        
    <article class="margin10">
        <ul class="index">
            <li class="">
                <a class="botonNuevo" href="item/create"> + Nuevo</a>
            </li>
            <?php if(isset($guardarropa)): ?>         
            <form method="POST" id="filtro" action="/guardarropa" name="filtro" class="index" style="text-align: center;" enctype="multipart/form-data">
                <?php echo csrf_field(); ?> 
                <?php echo method_field("GET"); ?> 
                <?php if(isset($mensaje)): ?>             
                    <p> <?php echo e($mensaje); ?> </p>
                <?php endif; ?>
                    <li class="">
                    <label for="categoria"></label>
                    <select name="categoria" id="mySelect" class="categoria filtro" type="number">
                            <option disabled selected>items<option>
                            <option value="0" <?php echo e(isset($selectCat) && $selectCat==="0" ? 'selected' : ''); ?>>todos</option>
                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                                <option value=<?php echo e($cat['id']); ?> <?php echo e(isset($selectCat) && $selectCat===$cat['id'] ? 'selected' : ''); ?>><?php echo e($cat['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    </li>                    
                    <li>
                        <button class="botonFilter" typy="submit" name="filtro">Filtrar</button>
                    </li>
            </form>
            <li><a href="/outfit/create" class="botonCrear">Crear Look!</a></li>            
        </ul>

        <div>
            <?php if(isset($mensaje)): ?>
                    <p> <?php echo e($mensaje); ?> </p>
            <?php endif; ?>
        </div>        
    </article>    
    <article>    
        <ul class="index">

        <?php if(isset($selectCat) && $selectCat !== "0"): ?>
            <?php $__currentLoopData = $guardarropa->item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <?php if($i->categoria_id === $selectCat): ?>       
                    <li> 
                        <div class="index cajaIndex"> 
                            <a class="cajaImgIndex" href="item/<?php echo e($i->id); ?>">
                            <img class="imgIndex" src="<?php echo e(asset($i->photo)); ?>" alt="Icono de <?php echo e($i->name); ?> ">        
                            </a>

                            <div class="index optIndex">
                                <a class="links" href="/item/<?php echo e($i->id); ?>/delete"><i class="far fa-trash-alt"></i></a>
                                <a class="links" href="item/<?php echo e($i->id); ?>"> Info </a>
                                <!-- MEJORAR QUE EL 5 ESTE MANEJADO DESDE PANTALLA DEL ADMINISTRADOR --> 
                                <?php if($i['categoria_id'] < 5): ?> 
                                    <a class="links" href="outfit/<?php echo e($i->id); ?>"> Looks </a>   
                                <?php endif; ?>
                            </div>
                        </div>
                    </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>

        <?php for($c=1 ; $c<($categ+1) ; $c++): ?>                    
            <?php $__currentLoopData = $guardarropa->item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <?php if($i->categoria_id === $c): ?>       
                    <li> 
                        <div class="cajaIndex"> 
                            <a class="cajaImgIndex" href="item/<?php echo e($i->id); ?>">
                                <img class="imgIndex" src="<?php echo e(asset($i->photo)); ?>" alt="Icono de <?php echo e($i->name); ?> ">        
                            </a>
    
                            <div class="index optIndex">
                                <a class="links" href="/item/<?php echo e($i->id); ?>/delete"> <i class="far fa-trash-alt"></i> </a>
                                <a class="links" href="item/<?php echo e($i->id); ?>"> Info </a>
                                <!-- MEJORAR QUE EL 5 ESTE MANEJADO DESDE PANTALLA DEL ADMINISTRADOR --> 
                                <?php if($i['categoria_id'] < 5): ?> 
                                    <a class="links" href="outfit/<?php echo e($i->id); ?>"> Looks </a>   
                                <?php endif; ?>
                            </div>
                        </div>
                    </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endfor; ?>
        
        <?php endif; ?>
        </ul>          
    </article> 
    <?php endif; ?>
   
</section>

<script rel="javascript" type="text/javascript" src="../js/wglam.js"></script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>