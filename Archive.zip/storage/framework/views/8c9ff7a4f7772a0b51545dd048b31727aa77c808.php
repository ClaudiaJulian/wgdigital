<?php $__env->startSection('content'); ?>



<section class="white">
    <div class="">
        <ul class="nav-menu">                                   
            <li><a href="/item">Home</a></li>         
            <li><a href="/guardarropa">Mi Guardarropa</a></li>                
            <li><a href="/outfit">Mis Looks</a></li>            
            <li><a href="/producto/shop">Shop</a></li>
            <li><a href="/guardarropa">Ayuda</a></li>                    
        </ul>  
    </div>


    <div class="BannerPerfil">
        <li class="shopTx">Que matchee con vos y tu guardarropa</li>
    </div>
</section>

<ul class="errors">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<section class="principal">    
        <section class="" style="padding-top:20px;padding-bottom:20px;">
        <div class="index">
            <li class="">
                <form>
                    <label></label>
                        <select name="tipo_w" id="tipo_w" class="tipo_w filtro" type="number">
                            <option selected disabled>Guardarropa</option>
                            <?php $__currentLoopData = $wardrobe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                            <option value=<?php echo e($w['id']); ?>><?php echo e($w['nombre']); ?></option>                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>                    
                </form>
            </li>
            <li class="">
                <form>
                    <label></label>
                        <select name="categoria" id="mySelect" class="categoria filtro" type="number">
                            <option selected disabled>categoria</option>
                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                                    <option value=<?php echo e($cat['id']); ?>><?php echo e($cat['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>                    
                </form>
            </li>
            <li class="">
                <form>
                    <label></label>
                        <select name="corte" id="mySelect" class="corte filtro" type="number">
                            <option selected disabled>corte</option>
                                <?php $__currentLoopData = $forma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                                    <option value=<?php echo e($f['id']); ?>><?php echo e($f['nombre']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>                    
                </form>
            </li>
        </div>

        <div class="">   
                <ul class="index">
                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        
                            <?php if(in_array($pro->user_id,$arrayOff)): ?>
                            <?php else: ?>
                            <li >
                            
                            <div class="cajaIndex">
                                
                                <?php if($pro->categoria_id < 11): ?>
                                    <?php if(isset($love)): ?>
                                        <a ><i class="far fa-heart"></i> <i class="fas fa-heart"></i></a> 
                                    <?php else: ?>
                                    <div class="love index" id=<?php echo e($pro->id); ?>>
                                        <p class="texto" style="color:white;font-size:0.8em;margin:0px;padding-right:5px;" id=<?php echo e($pro->id); ?>>subilo a tu guardarropa</p>       
                                        <a href="/producto/subir_produc/<?php echo e($pro->id); ?>"><i class="far fa-heart"></i></a> 
                                    </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            
                                <a class="cajaImgIndex"  href="/producto/shop/<?php echo e($pro->id); ?>">
                                    <img class="imgIndex" src="<?php echo e(asset($pro->photo)); ?>" alt="Icono de <?php echo e($pro->name); ?> ">                                        
                                </a>
                            
                                <div class="index optIndex" >
                                    <a class="links" > <?php echo e($pro->brand); ?> </a>
                                    <a class="links" > $ <?php echo e($pro->precio); ?> </a>
                                    <a class="links"  href="/producto/shop/<?php echo e($pro->id); ?>"> <i class="fas fa-shopping-bag"></i> </a>
                                </div>
                            </div>
                            </li>
                            <?php endif; ?>                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>          
        </div>         
        </section>    
        
    </section>
    <script rel="javascript" type="text/javascript" src="../js/wglam.js"></script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>