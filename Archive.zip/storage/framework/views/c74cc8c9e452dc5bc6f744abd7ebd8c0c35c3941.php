<?php $__env->startSection('content'); ?>

<div class="index" style="padding-bottom:20px;padding-top:20px;">
    
    <ul class="cajaOutfit">    
        
        <li class="column1"> 
            <div class="boxtop">
                <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($i->id === $outfit->t_id): ?>                               
                         <img class="masterTop topFor" src=<?php echo e(asset($i->photo)); ?> id="" alt=<?php echo e($outfit->t_id); ?> >
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            <div class="boxbottom">
                <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($i->id === $outfit->b_id): ?> 
                        <img class="masterBottom bottomFor" src=<?php echo e(asset($i->photo)); ?> id="" alt=<?php echo e($outfit->b_id); ?> >
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
            </div>                 
        </li>
        <li class="column2">
            <div class="boxoutwear">
                <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($i->id === $outfit->o_id): ?> 
                        <img class="masterOutwear outFor" src=<?php echo e(asset($i->photo)); ?> id="" alt=<?php echo e($outfit->o_id); ?>>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            <div class="boxacc">
                <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($i->id === $outfit->ba_id): ?> 
                        <img class="masterBag bag" src=<?php echo e(asset($i->photo)); ?> id="" alt=<?php echo e($outfit->ba_id); ?>>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
            </div>  
            
            <div class="boxshoes">
                <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($i->id === $outfit->s_id): ?>
                        <img class="masterShoes bag" src=<?php echo e(asset($i->photo)); ?> id="" alt=<?php echo e($outfit->s_id); ?>>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>               
            </div>                   
        <!-- <img class="other" src="" alt="Choose OTHER">  -->
        </li>

    <div class="nav-foot">
    <?php if($outfit->work === 1): ?> <p style="margin:5px;">Office Day</p> <?php endif; ?>
    <?php if($outfit->day === 1): ?> <p style="margin:5px;">WeekEnd</p> <?php endif; ?>
    <?php if($outfit->night === 1): ?> <p style="margin:5px;">Night Out</p> <?php endif; ?>
    </div>

</div>
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>