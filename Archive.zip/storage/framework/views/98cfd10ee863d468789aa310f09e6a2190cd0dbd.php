<?php $__env->startSection('content'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<section class="white">
    <div class="">
        <ul class="nav-menu">                                   
            <li><a href="/outfit/mastercreate">Try!</a></li>         
            <li><a href="/guardarropa">Mi Guardarropa</a></li>                
            <li><a href="/outfit">Mis Looks</a></li>            
            <li><a href="/producto/shop">Shop</a></li>
            <li><a href="/guardarropa">Ayuda</a></li>                    
        </ul>  
    </div>
        
    <div class="BannerItem">
        <p>Subí nuestros items ó tus propias fotos</p>        
    </div>
</section>

<section class="principal">
    <div class="index">        
            <form method="POST" id="filtro" action="/item" name="filtro" class="index" style="text-align: center;" enctype="multipart/form-data">
                <?php echo csrf_field(); ?> 
                <?php echo method_field("GET"); ?> 
                <li class="">
                    <label for="tipo_w"></label>
                    <select name="tipo_w" id="tipo_w" class="tipo_w filtro" type="number">
                        <option disabled selected>guardarropa<option>
                        <option value="0" <?php echo e(isset($selectWar) && $selectWar==="0" ? 'selected' : ''); ?>>todos</option>
                            <?php $__currentLoopData = $wardrobe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                            <option value=<?php echo e($w['id']); ?> <?php echo e(isset($selectWar) && $selectWar===$w['id'] ? 'selected' : ''); ?>><?php echo e($w['nombre']); ?></option>                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>  
                </li>
                <li class="">
                    <label for="categoria"></label>
                    <select name="categoria" id="mySelect" class="categoria filtro" type="number">
                        <option disabled selected>items<option>
                        <option value="0" <?php echo e(isset($selectCat) && $selectCat==="0" ? 'selected' : ''); ?>>todos</option>
                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                  
                                <option value=<?php echo e($cat['id']); ?> <?php echo e(isset($selectCat) && $selectCat===$cat['id'] ? 'selected' : ''); ?>><?php echo e($cat['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </select>                    
                </li>
                <li>
                <button class="botonFilter" type="submit" name="filtro">Filtrar</button>
                </li>
            </form>
    </div>
    <div class="margin10">       
        <ul class="index">
        <?php for($c=1 ; $c<$categ ; $c++): ?>              
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->categoria_id === $c): ?>
                <li >  
                    <div class="cajaIndex">
                        <a class="cajaImgIndex" href="item/<?php echo e($item->id); ?>">
                            <img class="imgIndex" src="<?php echo e(asset($item->photo)); ?>" alt="Icono de <?php echo e($item->name); ?> "> 
                        </a>
                        <div class="index optIndex">
                            <a class="links" href="/guardarropa/add/<?php echo e($item->id); ?>"> Subir </a>
                            <a class="links" href="item/<?php echo e($item->id); ?>"> Info </a>
                        </div>
                    </div>
                </li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endfor; ?>
        </ul>          
    </div> 
   
</section>

<script rel="javascript" type="text/javascript" src="../js/wglam.js"></script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>