<?php $__env->startSection('content'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>


    <section>
        <div class="white">
            <ul class="nav-menu">                  
                <li><a  href="/item">Home</a></li>
                <li><a  href="/guardarropa">Guardarropa</a></li>
                <li><a  href="/outfit">Looks</a></li>
                <li><a  href="/guardarropa">Assistant</a></li>
                <li><a  href="/guardarropa">Shop</a></li>
            </ul>
        </div>
    </section>    
    <section class="principal">
        <form method="POST" id="nuevo" action="" name="nuevo" style="text-align: center;" enctype="multipart/form-data"> 
        <?php echo csrf_field(); ?>  
            <div class="formCreate">
            <ul class="indexColumn">
                <li class="index">
                    <div class="">                      
                        <img src=<?php echo e(asset('/wGlam.png')); ?> style="width:100%;padding:10px;max-width:400px;" alt="wGlam">                     
                    </div>
                </li>
                <li class="index">
                    <div  style="width:170px;height:30px;">
                        <label for="img"></label>
                        <img type="hidden" src="" style="width:100%;padding:10px;display:none;" alt="wGlam">   
                        <input type="file" name="img" id="img" value="">
                    </div>
                </li> 
                <li> 
                    <p class="info"></p>  
                </li>
            </ul>
    
            <div class="indColumn">
            <ul class="errors">
                <?php if($errors->all()): ?><li> Faltan completar campos.</li> <?php endif; ?>        
                
            </ul>    
            <ul>
                <li>
                    <label for="categoria"></label>
                    <select name="categoria" id="mySelect" class="categoria inputCreate" type="number">
                        <option selected disabled> Categoría</option>
                        <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                        <option value=<?php echo e($cat['id']); ?> <?php echo e(((int)old('categoria') === $cat['id'])? 'selected':''); ?>><?php echo e($cat['name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </li>
                <li>
                    <label for="name"></label>
                    <input type="text" class="inputCreate" name="name" placeholder="Nombre" id="name de producto" value=<?php echo e(old('name')); ?> >
                </li>
                <li>    
                    <label for="brand"></label>
                    <input type="text" class="inputCreate" name="brand" placeholder="<?php echo e(Auth::user()->name); ?>" id="brand" value="<?php echo e(Auth::user()->name); ?>">
                </li>     

                <li>    
                    <label for="precio"></label>
                    <input type="number" class="inputCreate" name="precio" placeholder="Precio" id="precio" value=<?php echo e(old('precio')); ?>>
                </li>     
                <li>    
                    <label for="descuento"></label>
                    <input type="number" class="inputCreate" name="descuento" placeholder="Descuento" id="descuento" value=<?php echo e(old('descuento')); ?>>
                </li>                     

                <li class="printed">
                    <label for="printed"></label>
                        <select name="printed" class="inputCreate" type="number">
                            <option selected disabled>Estampado</option>
                            <?php $__currentLoopData = $estampado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                            <option value=<?php echo e($e['id']); ?> <?php echo e(((int)old('printed') === $e['id'])? 'selected':''); ?>><?php echo e($e['nombre']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                </li>    
                <li class="colored">
                    <label for="colored"></label>
                        <select name="colored" class="inputCreate" type="number">
                            <option selected disabled>Color</option>
                            <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                            <option value=<?php echo e($col['id']); ?> <?php echo e(((int)old('colored') === $col['id'])? 'selected':''); ?>><?php echo e($col['nombre']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                </li>
                <li class="form">
                    <label for="form"></label>
                        <select name="form" type="number" class="inputCreate refForm">
                            <option selected disabled>Forma</option>
                            <?php $__currentLoopData = $forma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                            <option value=<?php echo e($f['id']); ?> <?php echo e(((int)old('form') === $f['id'])? 'selected':''); ?>><?php echo e($f['nombre']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                </li>
                <li class="length">
                    <label for="length"></label>
                        <select name="length" type="number" class="inputCreate refLen">
                            <option selected disabled>Largo</option>
                            <?php $__currentLoopData = $largo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                            <option value=<?php echo e($l['id']); ?> <?php echo e(((int)old('length') === $l['id'])? 'selected':''); ?>><?php echo e($l['nombre']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </li>
                <li class="tipo_w">
                    <label for="tipo_w"></label>
                        <select name="tipo_w" class="inputCreate" type="number">
                            <option selected disabled>Tipo de Guardarropa</option>
                            <?php $__currentLoopData = $wardrobe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                            <option value=<?php echo e($w['id']); ?> <?php echo e(((int)old('tipo_w') === $w['id'])? 'selected':''); ?>><?php echo e($w['nombre']); ?></option>                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                </li>   
                <li>
                    <label for="descrip"></label>
                    <textarea type="text" class="" name="descrip" placeholder="Descripción del Producto" id="descrip" value="<?php echo e(old('descrip')); ?>" ></textarea>
                </li>

                <li>
                    <label for="on_off"></label>
                        <select name="on_off" class="inputCreate" type="number">
                            <option selected disabled>on_off</option>                                 
                            <option value="on">on</option>
                            <option value="off">off</option>                     
                        </select>
                </li>
                <button type="submit" class="botonGral" name="button">Grabar</button>    
            </ul>
            </div>    
                        
            
        </div>
           
        </form>
       
    </section>

<script rel="javascript" type="text/javascript" src="../js/wglam.js"></script> 


<?php $__env->stopSection(); ?>




<?php echo $__env->make('template.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>