<html>
    <ul class="pagination">
   <li class="page-item">
       <a class="page-link" href="" rel="prev">hola</a>
       
   </li>
   <li class="page-item">
        <a class="page-link" href="" rel="Next">chau</a>
   </li>
</ul>
   
</html>