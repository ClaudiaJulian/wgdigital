<?php

use Illuminate\Database\Seeder;
use App\Item;

class ItemsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Item::create([
            'user_id' => '1',
            'name' => 'wGlam',
            'brand' => 'wGlam',
            'categoria_id' => '1',
            'printed' => '1',
            'colored' => '1',
            'form' => '1',
            'length' => '1',
            'tipo_w' => '1',
            ]);
        Item::create([
            'user_id' => '1',
            'name' => 'wGlam',
            'brand' => 'wGlam',
            'categoria_id' => '1',
            'printed' => '1',
            'colored' => '1',
            'form' => '1',
            'length' => '1',
            'tipo_w' => '1',
            ]);     
        Item::create([
            'user_id' => '1',
            'name' => 'wGlam',
            'brand' => 'wGlam',
            'categoria_id' => '1',
            'printed' => '1',
            'colored' => '1',
            'form' => '1',
            'length' => '1',
            'tipo_w' => '1',
            ]);     
        Item::create([
            'user_id' => '1',
            'name' => 'wGlam',
            'brand' => 'wGlam',
            'categoria_id' => '1',
            'printed' => '1',
            'colored' => '1',
            'form' => '1',
            'length' => '1',
            'tipo_w' => '1',
            ]);     
        Item::create([
            'user_id' => '1',
            'name' => 'wGlam',
            'brand' => 'wGlam',
            'categoria_id' => '1',
            'printed' => '1',
            'colored' => '1',
            'form' => '1',
            'length' => '1',
            'tipo_w' => '1',
            ]);     
        Item::create([
            'user_id' => '1',
            'name' => 'wGlam',
            'brand' => 'wGlam',
            'categoria_id' => '1',
            'printed' => '1',
            'colored' => '1',
            'form' => '1',
            'length' => '1',
            'tipo_w' => '1',
            ]);     
        Item::create([
            'user_id' => '1',
            'name' => 'wGlam',
            'brand' => 'wGlam',
            'categoria_id' => '1',
            'printed' => '1',
            'colored' => '1',
            'form' => '1',
            'length' => '1',
            'tipo_w' => '1',
            ]);     
        Item::create([
            'user_id' => '1',
            'name' => 'wGlam',
            'brand' => 'wGlam',
            'categoria_id' => '1',
            'printed' => '1',
            'colored' => '1',
            'form' => '1',
            'length' => '1',
            'tipo_w' => '1',
            ]);     
        Item::create([
            'user_id' => '1',
            'name' => 'wGlam',
            'brand' => 'wGlam',
            'categoria_id' => '1',
            'printed' => '1',
            'colored' => '1',
            'form' => '1',
            'length' => '1',
            'tipo_w' => '1',
            ]);     
        Item::create([
            'user_id' => '1',
            'name' => 'wGlam',
            'brand' => 'wGlam',
            'categoria_id' => '1',
            'printed' => '1',
            'colored' => '1',
            'form' => '1',
            'length' => '1',
            'tipo_w' => '1',
            ]);
        Item::create([
            'user_id' => '1',
            'name' => 'wGlam',
            'brand' => 'wGlam',
            'categoria_id' => '1',
            'printed' => '1',
            'colored' => '1',
            'form' => '1',
            'length' => '1',
            'tipo_w' => '1',
            ]);                                          
    }
}