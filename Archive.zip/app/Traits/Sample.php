<?php


namespace App\Traits;


trait Sample {
    
    function testMethod($p){
        echo $p;
    }

}
