<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ojo extends Model
{
    //
}
