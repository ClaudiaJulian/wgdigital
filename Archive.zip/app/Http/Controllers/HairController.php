<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HairController extends Controller
{
    //
}
