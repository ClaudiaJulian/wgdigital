<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UsoController extends Controller
{
    //
}
