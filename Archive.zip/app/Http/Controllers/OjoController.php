<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class OjoController extends Controller
{
    //
}
