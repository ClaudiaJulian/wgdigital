<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Cuerpo;

class Cuerpo extends Model
{
    protected $guarded = [];
}
