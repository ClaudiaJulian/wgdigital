<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Skin extends Model
{
    //
}
